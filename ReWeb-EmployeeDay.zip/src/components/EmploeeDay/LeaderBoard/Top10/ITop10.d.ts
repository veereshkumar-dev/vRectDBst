import * as React from 'react';

export interface Top10Props {
  className?: string;
  children?: React.ReactNode;
}

export function Top10(props: Top10Props): React.ReactNode;
