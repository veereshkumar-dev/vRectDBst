import * as React from 'react';

export interface Top3Props {
  className?: string;
  children?: React.ReactNode;
}

export function Top3(props: Top3Props): React.ReactNode;
