import * as React from 'react';

export interface EmploeeDayProps {
  className?: string;
  children?: React.ReactNode;
}

export function EmploeeDay(props: EmploeeDayProps): React.ReactNode;
