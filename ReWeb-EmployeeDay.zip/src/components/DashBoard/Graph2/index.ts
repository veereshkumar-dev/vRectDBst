export { default } from "./Graph2";
