export enum Direction {
  BotStore = 1,
  Dashboard,
  KnowledgeBase,
}
