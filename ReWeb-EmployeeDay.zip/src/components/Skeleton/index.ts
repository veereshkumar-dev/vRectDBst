export { default } from "./Skeleton";
