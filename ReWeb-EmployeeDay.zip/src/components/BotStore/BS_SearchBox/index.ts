export { default } from "./BS_SearchBox";
