import * as React from 'react';

export interface BS_SearchBoxProps {
  className?: string;
  children?: React.ReactNode;
}

export function BS_SearchBox(props: BS_SearchBoxProps): React.ReactNode;
