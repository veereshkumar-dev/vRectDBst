export { default } from "./DetailsCard";
