export { default } from "./BS_Rating";
