export { default } from "./Tabs";
