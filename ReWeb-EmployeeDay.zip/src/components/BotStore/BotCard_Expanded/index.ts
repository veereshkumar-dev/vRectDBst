export { default } from "./BotCard_Expanded";
