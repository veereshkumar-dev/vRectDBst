import * as React from 'react';

export interface OceanProps {
  className?: string;
  children?: React.ReactNode;
}

export function Ocean(props: OceanProps): React.ReactNode;
