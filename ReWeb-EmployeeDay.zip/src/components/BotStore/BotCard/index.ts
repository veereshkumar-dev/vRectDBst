export { default } from "./BotCard";
